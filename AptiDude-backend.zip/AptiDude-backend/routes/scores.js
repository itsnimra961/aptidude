﻿const express = require('express');
const Score = require('../models/Score');
const User = require('../models/User');
const auth = require('../middleware/auth');

const router = express.Router();

// Submit game score
router.post('/', auth, async (req, res) => {
  try {
    const { gameName, score, timeSpent, attempts, completed, difficulty } = req.body;
    const newScore = new Score({
      userId: req.userId,
      gameName,
      score,
      timeSpent,
      attempts,
      completed,
      difficulty,
    });

    await newScore.save();

    // Update user total score
    const user = await User.findById(req.userId);
    user.totalScore += score;
    user.gamesPlayed += 1;
    await user.save();

    res.status(201).json({
      message: 'Score saved successfully',
      score: newScore,
    });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Get user's game history
router.get('/user/:userId', async (req, res) => {
  try {
    const scores = await Score.find({ userId: req.params.userId }).sort({
      createdAt: -1,
    });
    res.json(scores);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

// Get global leaderboard
router.get('/leaderboard/global', async (req, res) => {
  try {
    const leaderboard = await User.find()
      .select('name levelsCompleted gamesPlayed rank')
      .sort({ levelsCompleted: -1 })
      .limit(100);

    const rankedLeaderboard = leaderboard.map((user, index) => ({
      ...user.toObject(),
      rank: index + 1,
    }));

    res.json(rankedLeaderboard);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

// Get scores for specific game
router.get('/game/:gameName', async (req, res) => {
  try {
    const scores = await Score.find({ gameName: req.params.gameName })
      .populate('userId', 'name')
      .sort({ score: -1 })
      .limit(50);

    res.json(scores);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

// Get user's best scores
router.get('/best/:userId', async (req, res) => {
  try {
    const bestScores = await Score.find({ userId: req.params.userId })
      .sort({ score: -1 })
      .limit(10);

    res.json(bestScores);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

// Submit level completion
router.post('/levels/complete', auth, async (req, res) => {
  try {
    const { subjectId, unitId, levelId } = req.body;

    // Update user levelsCompleted
    const user = await User.findById(req.userId);
    user.levelsCompleted += 1;
    await user.save();

    res.status(201).json({
      message: 'Level completed successfully',
      levelsCompleted: user.levelsCompleted,
    });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

module.exports = router;
