const mongoose = require('mongoose');

const gameSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      enum: ['Sudoku', 'LogicPuzzle', 'WordChain'],
    },
    description: String,
    difficulty: {
      type: String,
      enum: ['Easy', 'Medium', 'Hard'],
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Game', gameSchema);