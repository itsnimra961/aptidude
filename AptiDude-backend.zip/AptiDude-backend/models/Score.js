const mongoose = require('mongoose');

const scoreSchema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    gameId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Game',
    },
    gameName: {
      type: String,
      enum: ['Sudoku', 'LogicPuzzle', 'WordChain'],
      required: true,
    },
    score: {
      type: Number,
      required: true,
    },
    timeSpent: Number,
    attempts: {
      type: Number,
      default: 1,
    },
    completed: {
      type: Boolean,
      default: false,
    },
    difficulty: {
      type: String,
      enum: ['Easy', 'Medium', 'Hard'],
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Score', scoreSchema);