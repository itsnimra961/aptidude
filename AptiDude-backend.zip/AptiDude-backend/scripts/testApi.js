(async () => {
  const base = 'http://localhost:5000/api';
  const timestamp = Date.now();
  const email = `apitest+${timestamp}@example.com`;
  const password = 'Test1234';
  const name = 'APITest';

  function log(title, obj) {
    console.log('\n==== ' + title + ' ====');
    try { console.log(typeof obj === 'string' ? obj : JSON.stringify(obj, null, 2)); }
    catch(e){ console.log(obj); }
  }

  try {
    // Register
    const regRes = await fetch(`${base}/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, email, password }),
    });
    const regJson = await regRes.json();
    log('REGISTER', { status: regRes.status, body: regJson });

    // Login
    const loginRes = await fetch(`${base}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    });
    const loginJson = await loginRes.json();
    log('LOGIN', { status: loginRes.status, body: loginJson });

    const token = loginJson.token;
    if (!token) {
      console.error('No token returned; aborting further tests.');
      process.exit(1);
    }

    // Get games
    const gamesRes = await fetch(`${base}/games`);
    const gamesJson = await gamesRes.json();
    log('GAMES', { status: gamesRes.status, body: gamesJson });

    // Submit score
    const firstGame = (gamesJson && gamesJson.length && gamesJson[0].name) ? gamesJson[0].name : 'Sudoku';
    const scorePayload = { gameName: firstGame, score: 42, timeSpent: 90, attempts: 1, completed: true, difficulty: 'Medium' };
    const scoreRes = await fetch(`${base}/scores`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
      body: JSON.stringify(scorePayload),
    });
    const scoreJson = await scoreRes.json();
    log('SUBMIT_SCORE', { status: scoreRes.status, body: scoreJson });

    // Leaderboard
    const lbRes = await fetch(`${base}/scores/leaderboard/global`);
    const lbJson = await lbRes.json();
    log('LEADERBOARD', { status: lbRes.status, top: Array.isArray(lbJson) ? lbJson.slice(0,5) : lbJson });

    console.log('\nAll tests completed.');
    process.exit(0);
  } catch (err) {
    console.error('Test error:', err);
    process.exit(1);
  }
})();
