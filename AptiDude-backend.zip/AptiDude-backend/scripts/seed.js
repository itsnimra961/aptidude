require('dotenv').config();
const mongoose = require('mongoose');
const Game = require('../models/Game');
const User = require('../models/User');

async function main() {
  try {
    await mongoose.connect(process.env.MONGODB_URI, { useNewUrlParser: true, useUnifiedTopology: true });
    console.log('MongoDB connected for seeding');

    // Clear existing games (for idempotence)
    await Game.deleteMany({});

    const games = [
      { name: 'Sudoku', description: 'Fill the 9x9 grid with numbers. Each row, column, and 3x3 box must contain all digits 1-9.', difficulty: 'Medium' },
      { name: 'LogicPuzzle', description: 'ZIP-like numeric puzzle: find numbers that add to a target.', difficulty: 'Easy' },
      { name: 'WordChain', description: 'N-Queens style logic puzzle (placeholder name).', difficulty: 'Hard' },
    ];

    const created = await Game.insertMany(games);
    console.log('Inserted games:', created.map(g => g.name).join(', '));

    // Create a test user (remove existing with same email first)
    const testEmail = 'dev@aptidude.local';
    await User.deleteOne({ email: testEmail });

    const testUser = new User({ name: 'Dev Tester', email: testEmail, password: 'Test1234' });
    await testUser.save();
    console.log('Created test user:', testUser.email);

    console.log('Seeding complete');
    process.exit(0);
  } catch (err) {
    console.error('Seeding error:', err);
    process.exit(1);
  }
}

main();
